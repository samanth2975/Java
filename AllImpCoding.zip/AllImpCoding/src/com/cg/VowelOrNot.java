package com.cg;

import java.util.Scanner;

public class VowelOrNot {
	public static void main(String[] args) {
		char c = 'k';
		if(c == 'a' ||c == 'e' || c == 'i' || c == 'o' || c == 'u') {
			System.out.println(c+ "is vowel");
		}
		else
		{
			System.out.println(c+ " is consonant");
			
		}
	}




         
		
		// OR
		
		
//		Scanner input = new Scanner(System.in);
//		System.out.println("Enter a string :");
//		String s = input.next();
//		
//		System.out.println("Enter a vowel :");
//		char c =input.next().charAt(0);
//		int f=0;
//		
//		for(int i=0; i<s.length(); i++) {
//			if(c==s.charAt(i))
//			{
//				System.out.println("Vowel Present");
//				f=1;
//				break;
//			}
//			}
//		if(f==0) {
//			System.out.println("no Vowel");
//			}
//		
//		
		
		
		
		
		
//		System.out.println(stringContainsVowels("Hello")); // true
//		System.out.println(stringContainsVowels("TV")); // false
//	}
//
//	public static boolean stringContainsVowels(String input) {
//		return input.toLowerCase().matches(".*[aeiou].*");
//	}
	}


		
		
	
