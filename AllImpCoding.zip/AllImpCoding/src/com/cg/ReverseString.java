package com.cg;

public class ReverseString 
{
//	public static void main(String args[]) {
//	String name ="kiran";
//
//	int l1 = name.length();
//	System.out.println(l1);
//
//	String rev = "";
//	for(int i =l1-1; i>=0;i--) {
//	rev = rev+name.charAt(i);
//	
//	}
//	System.out.println(rev);
//}
	
	public static void main(String[] args) {

       

        String str = "Automation";

        StringBuilder str2 = new StringBuilder();

        str2.append(str);

        str2 = str2.reverse();     // used string builder to reverse

       System.out.println(str2);

        }
		
	
}

