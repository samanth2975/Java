package exceptionhandling;

public class ExceptionHandlingRunner {

	public static void main(String[] args) {

		call();
		System.out.println("callMethod");
	}

	static void call() {
		// by using null we will geet null pointer exception
		// String str = null;
		String str = "mounika";
		int len = str.length();
		System.out.println("String Length====>" + len);
		System.out.println("String ====>" + str);
	}

}
