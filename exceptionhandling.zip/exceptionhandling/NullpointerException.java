package exceptionhandling;

public class NullpointerException {
//If we have a null value in any variable, performing  operation 
	// on the variable throws a NullPointerException.
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		method1();
		System.out.println("main()");
	}

	static void method1() {
		method2();
		System.out.println("method1()");
	}

	static void method2() {
		try {
			String str = null;
			int len = str.length();
			System.out.println("method2()");
		} catch (NullPointerException e) {
			System.out.println("NullPointerException");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}



}
