package exceptionhandling;

public class ArrayIndexOutOfBoundsException1{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		method1();
		// method2();
		System.out.println("main()");
	}

	public static void method1() {
		method2();
		System.out.println("method1()");
	}

	static void method2() {
		try {
			// int[] numbers = { 1, 2, 3, 4 };
			int[] numbers = { 1, 2 };
			int num = numbers[3];
			System.out.println("method2()");
		} catch (NullPointerException e) {
			System.out.println("NullPointerException");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}


}
