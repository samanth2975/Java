package exceptionhandling;

public class ExceptionTest {

	public static void main(String[] args) {

		callOne();
	}

	public static void callOne() {
		callTwo();
	}

	public static void callTwo() {
		callThree();
	}

	public static void callThree() {
		String name = null;
		System.out.println(name.length());
	}

}
