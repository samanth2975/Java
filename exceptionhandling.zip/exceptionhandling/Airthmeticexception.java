package exceptionhandling;

public class Airthmeticexception {

	public static void main(String[] args) {
//If we divide any number by zero, there occurs an ArithmeticException.
		 try{  
				// raise exception
		      int data=100/0;  
			} catch (ArithmeticException e) {
				System.out.println(e);
			}

			System.out.println("=========");
			System.out.println("airtmetic exception occurs above try block");
		  }  

}
