package exceptionhandling;

public class ExceptionTry {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		method1();
		System.out.println("main()");
	}

	static void method1() {
		method2();
		System.out.println("method1()");
	}

	static void method2() {
		try {// program-logic code block
			String str = null;
			int len = str.length();
			System.out.println("method2()");
		} catch (Exception ex) {// exception-handling code block

			ex.printStackTrace();// method gives debug information to the programmer
		}
	}

}
